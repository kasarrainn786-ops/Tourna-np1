TOURNA NP - HIGH FIDELITY FRONT-END PROTOTYPE

This version was redesigned from the uploaded Tourna NP reference images. It uses cropped assets from those images for the logo, gaming/mountain background and profile avatar.

Included screens/settings:
- Splash/login visual direction
- Login: email/phone + password, remember me, forgot password, Google, Facebook, Register
- Home with Tourna NP logo, Free Fire hero, live tournament, Tournaments, My Games, Wallet and bottom navigation
- Tournaments and join flow with entry fee, prize, slots, match code, Game UID/IGN
- My Games with match history and room-details placeholder
- Wallet with balance, Add Points, withdrawal and transaction activity
- Profile Overview, Match History, Achievements, stats, wallet, user ID, email, location, joined date
- Admin panel: scoring settings, match creation, room ID/password, deposit/withdrawal requests
- Firebase Web SDK initialized with the supplied esport-np-2 project config

NOTE: Firebase config is client-side configuration. Real authentication, Firestore writes, payment verification, admin authorization and withdrawals still require secure Firebase rules/backend/Cloud Functions and eSewa/Khalti integration.


FIX FOR BLANK SCREEN:
Firebase initialization is now non-blocking. If Firebase/CDN is unavailable, the Tourna NP UI still loads instead of showing a black/blank page. Re-upload this ZIP to Netlify and redeploy.


BLANK SCREEN FIX V2:
- Firebase CDN scripts no longer block page startup.
- Firebase loads only in the background after the UI starts.
- Fixed logo/avatar asset paths.
- App should render without an internet connection to Firebase.


V3 FIX:
- Added missing app.js script to index.html. This was the cause of the page remaining on Loading Tourna NP.
- Copied logo.png and avatar.png to the project root for the app's image paths.
- Firebase config remains included and Firebase remains optional/non-blocking.
