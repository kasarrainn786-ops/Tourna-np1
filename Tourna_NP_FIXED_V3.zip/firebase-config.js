// Tourna NP Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC0I7ePyc2njix8M1TZ64BpH1TYZMOg-ts",
  authDomain: "esport-np-2.firebaseapp.com",
  projectId: "esport-np-2",
  storageBucket: "esport-np-2.firebasestorage.app",
  messagingSenderId: "924492595017",
  appId: "1:924492595017:web:03cb9a3509a53db3546498",
  measurementId: "G-P98EPXQE4V"
};

// Firebase is optional at page-load so the UI still works if the CDN is
// temporarily unavailable. Real auth/database calls can be connected later.
window.tournaFirebase = { ready: false };

try {
  if (window.firebase && typeof firebase.initializeApp === "function") {
    if (!firebase.apps || !firebase.apps.length) firebase.initializeApp(firebaseConfig);
    window.tournaFirebase.auth = firebase.auth();
    window.tournaFirebase.db = firebase.firestore();
    window.tournaFirebase.storage = firebase.storage();
    window.tournaFirebase.ready = true;
  }
} catch (err) {
  console.warn("Firebase initialization skipped:", err);
}
